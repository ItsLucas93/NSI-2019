Site Fiche Chronologique

### Page avec HTML Seulement, pour prouver la maîtrise du HTML5.

> Intégrer (minimum) deux lien qui redirige vers un site extérieur

### Page avec HTML/CSS

> Minimum deux photo

Bonus : Mettre du son, Bouton de progression


